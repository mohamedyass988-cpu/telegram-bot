
const fs = require("fs");
const chalk = require("chalk")

global.BOT_TOKEN = "8526935801:AAHyol6xewz_mzdyWTtl-zzMjoo9iOg2MMY" // create bot here https://t.me/Botfather and get bot token
global.BOT_NAME = "?????? ?????" //your bot name
global.OWNER_NAME = "@velkor_crash" //your name with sign @
global.OWNER = ["https://t.me/velkor_crash", "https://t.me/velkor_crash"] // Make sure the username is correct so that the special owner features can be used.
global.DEVELOPER = ["8590809949"] //developer telegram id to operate addprem delprem and listprem
global.pp = 'https://mora-host.zya.me/11.jpg' //your bot pp


//approval
global.GROUP_ID = -1003731239027; // Replace with your group ID
global.CHANNEL_ID =  -1003731239027; // Replace with your channel ID
global.GROUP_LINK = "https://t.me/"; // Replace with your group link
global.CHANNEL_INVITE_LINK = "https://t.me/velkor_crash"; // Replace with your private channel invite link
global.WHATSAPP_LINK = "https://t.me/velkor_crash"; // Replace with your group link
global.YOUTUBE_LINK = "https://www.youtube.com/@BLACKYT_11"; // Replace with your youtube link
global.INSTAGRAM_LINK = "https://www.instagram.com/velkor__xr?igsh=MWx4eHlsenh2dmYwag=="; // Replace with your ig link

global.owner = global.owner = ['+212727488449'] //owner whatsapp

const {
   english
} = require("./lib");
global.language = english
global.lang = language

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})