

//contact details
global.ownernomer = ".."
global.dev = ["..",".."]
global.ownername = "velkor"
global.ytname = "velkor"
global.socialm = "GitHub: velkor"
global.location = "Egypt, cairo, shopra"

global.ownernumber = '.'  //creator number
global.ownername = 'velkor' //owner name
global.botname = '𝐕𝐞𝐥𝐤𝐨𝐫 𝐜𝐫𝐚𝐬𝐡  𝐕9 🌴' //name of the bot

//sticker details
global.packname = '\n\n\n\n\n\n\nSticker By'
global.author = 'velkor ⚉\n\nContact: .'

//console view/theme
global.themeemoji = '🪀'
global.wm = "velkor."

//theme link
global.link = 'https://t.me/velkor_crash 
global.idch = '120363420146294598@newsletter'

global.baileysDB = 'baileysDB.json'
global.botDb = 'database.json'

//prefix
global.prefa = ['','!','.',',','🐤','🗿'] 

global.limitawal = {
    premium: "Infinity",
    free: 20
}

//menu type 
//v1 is image menu, 
//v2 is link + image menu,
//v3 is video menu,
//v4 is call end menu
global.typemenu = 'v1'

// Global Respon
global.mess = {
    success: 'Done✓',
    admin: `\`[ # ]\` This Command Can Only Be Used By Group Admins !`,
    botAdmin: `\`[ # ]\` This Command Can Only Be Used When Bot Becomes Group Admin !`,
    OnlyOwner: `\`[ # ]\` This Command Can Only Be Used By Premium User ! \n\nWant Premium? Chat Developer.\nTelegram: @Midoxkill\nWhatsApp: +20*********`,
    OnlyGrup: `\`[ # ]\` This Command Can Only Be Used In Group Chat !`,
    private: `\`[ # ]\` This Command Can Only Be Used In Private Chat !`,
    wait: `\`[ # ]\` Wait Wait a minute`,
    notregist: `\`[ # ]\` You are not registered in the Bot Database. Please register first.`,
    premium: `\`[ # ]\` This Command Can Only Be Used By Premium User ! \n\nWant Premium? Chat Developer.\nYouTube: @Midoxkill\nTelegram:@Midoxkill \nWhatsApp: +20*********`,
}

// ملف config.js
module.exports = {
    banner: [
        "01122220720@s.whatsapp.net",
        "20@s.whatsapp.net",
        "01122220720@s.whatsapp.net",
        "20@s.whatsapp.net",
        "20@s.whatsapp.net",
        "20@s.whatsapp.net"
    ]
};

let fs = require('fs')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})